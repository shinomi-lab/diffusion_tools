# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['difftools', 'difftools.diffusion', 'difftools.diffusion.multi']

package_data = \
{'': ['*']}

install_requires = \
['fire>=0.4.0,<0.5.0',
 'joblib',
 'matplotlib',
 'networkx',
 'numba',
 'numpy==1.21',
 'scipy']

setup_kwargs = {
    'name': 'diffusion-tools',
    'version': '0.2.4',
    'description': '',
    'long_description': None,
    'author': 'Shinomiya-Lab',
    'author_email': 'lab.shinomiya@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<=3.9',
}
from build import *
build(setup_kwargs)

setup(**setup_kwargs)
